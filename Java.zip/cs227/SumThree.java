/*Name: Kaung Lwin
  NetID: klwin
  SectionNumber: 1D
  Description: Prints out 3 numbers of the user and the result of those numbers added
*/


public class SumThree { //start of class
    public static void main(String [] args) { //start of main arg
        int x = Integer.parseInt(args[0]); //initialize the first arg
        int y = Integer.parseInt(args[1]); //initialize the second arg
        int z = Integer.parseInt(args[2]); //initialize the third arg
        int result = x+y+z; //initialize the result
        
        System.out.print( +x+ " + " +y+ " + " +z+ " = " + result + "\n"); //prints out the equation
    } //end of main arg
} //end of class
