public class MaxMin {

   public static void main(String[] args) {
    
              // the first value read is both the min and the max so far

      int max= StdIn.readInt();
      int min= max;
    
              // read in the data, adjust min and max as needed

      while (!StdIn.isEmpty()) {

         int value = StdIn.readInt();
         
         if(value > max){
             max = value;
         }
         
         if(value < min){
             min = value;
         }
         


      }
    
      StdOut.println("max = " + max + "   min = " + min);

   }
} 