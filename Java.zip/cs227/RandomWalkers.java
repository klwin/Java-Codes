/*Name: Kaung Lwin
  NetID: klwin
  SectionNumber: 1D
  Description: Takes two integer command-line arguments N and T. 
  In each of T independent experiments, simulate a random walk of N steps 
  and compute the squared distance. Output the mean squared distance
*/

import java.util.Random; //import utility
public class RandomWalkers { //start of class
    public static void main (String [] args) { //start of main method
        
        Random randomNumber = new Random(); //generate random number
        int nSteps = Integer.parseInt(args [0]); //takes first arg
        int tExperiments = Integer.parseInt(args [1]); //takes second arg
        //initialize variables
        int directions; 
        int x = 0;
        int y = 0;
        double distance = 0;
        double totalDistance = 0;
        double mean;
        
        for (int i  = 0; i < tExperiments; i++) { //first loop for tExperiments
            for (int j = 0; j < nSteps; j++) { //second loop for nSteps
                directions = randomNumber.nextInt(4); //random number from 0-3
                
             //if statements
                if(directions == 0) { //North
                    y++;
                }
                if(directions == 1) { //East
                    x++;
                }
                if(directions == 2) { //South
                    y--;
                }
                if(directions == 3) { //West
                    x--;
                }
                distance = (x * x) + (y * y); //compute the distance
            } //end of second loop
            
            totalDistance += distance; //add the distance each time to total
            x = 0; //reset the x
            y = 0; //reset the y
        } //end of first loop
        
        mean = totalDistance/tExperiments; //compute mean 
        System.out.println("mean squared distance = " + mean);
    } // end of main method
} // end of class
        