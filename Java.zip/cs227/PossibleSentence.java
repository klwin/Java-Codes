/*
   Assignment: Assignment #6 Possible Sentence
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: March, 12, 9:00pm
   
   Description: Scan the strings and tell what part of speech is each word.  
   Deficiencies: None
   */
   
import java.util.Scanner;//import scanner

public class PossibleSentence//start of the main method
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
   	
      System.out.print("Please enter a sentence to analyze: ");
      String sentence = keyboard.nextLine();
      
      System.out.println("");
   	
      Scanner stringScan = new Scanner(sentence);
   	
      //initialize the numbers of parts of the words
      int florb = 0;
      int wooble = 0;
      int zith = 0;
      int zarf = 0;
      int notIdentified = 0;
      
      //initialize the strings of parts of words
      String florbs = "";
      String woobles = "";
      String ziths = "";
      String zarfs = "";
      String notIdentifieds = "";
   
      //create loop that reads the sentence and extract each word
      while(stringScan.hasNext())
      {
         String word = stringScan.next();
      
      //rules for each words
         boolean identified = false;					
      
         if (word.charAt(0) != word.charAt(word.length() - 1)) {
            identified = true;
            florb++;
            florbs += word + " ";
            
         }
      
         if (word.indexOf("pq") > -1 || word.indexOf("zt") > -1) {
            identified = true;
            wooble++;
            woobles += word + " ";
         }
      
         if (word.indexOf('j') > -1 && (word.length() % 3 == 0 || word.length() % 4 == 0)) {
            identified = true;
            zith++;
            ziths += word + " ";
         }
      
         if (word.charAt(word.length() / 2) >= 'A' && word.charAt(word.length() / 2) <= 'Z') {
            identified = true;	
            zarf++;
            zarfs += word + " ";
         }
      
         if (!identified) {	
            notIdentified++;
            notIdentifieds += word + " ";
         }
      
      }
      //print statements with if 
      if (notIdentified == 0) {
         System.out.println("The sentence \'" +sentence+ "\' is valid according to the definition of our language.");
         System.out.println("");
      }
      if (notIdentified != 0) {
         System.out.println("The sentence \'" +sentence+ "\' is not valid according to the definition of our language.");
         System.out.println("");
      }
      if (florb != 0) {
         System.out.println("We were able to identify " +florb+ " florbs: \'" +florbs.substring(0,florbs.length()-1)+ "\'.");
      }
      if (wooble != 0) {
         System.out.println("We were able to identify " +wooble+ " woobles: \'" +woobles.substring(0,woobles.length()-1)+ "\'.");
      }
      if (zith != 0) {
         System.out.println("We were able to identify " +zith+ " ziths: \'" +ziths.substring(0,ziths.length()-1)+ "\'.");
      }
      if (zarf != 0) {
         System.out.println("We were able to identify " +zarf+ " zarfs: \'" +zarfs.substring(0,zarfs.length()-1)+ "\'.");
      }
      if (notIdentified != 0) {
         System.out.println("We were able to identify " +notIdentified+ " words that didn't belong to our language: \'" +notIdentifieds.substring(0,notIdentifieds.length()-1)+ "\'.");
       }
   }//end of main method
}//end of class
      
