/*
   Assignment: #3 GasMileage
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham   
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 12 9:00pm
   
   Description: The program will compute and print a gas mileage table.
   
   Deficiencies: no deficiencies
   */
   
import java.util.Scanner;
public class GasMileage {  // start of main method
   public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   //inputs   
   System.out.print ("Enter the miles driven in the first hour: ");
      float answer1 = keyboard.nextFloat();
   System.out.print ("Enter the gallons used in the first hour: ");
      float answer2 = keyboard.nextFloat();
   
   System.out.print ("\nEnter the miles driven in the second hour: ");
      float answer3 = keyboard.nextFloat();
   System.out.print ("Enter the gallons used in the second hour: ");
      float answer4 = keyboard.nextFloat();
   
   System.out.print ("\nEnter the miles driven in the third hour: ");
      float answer5 = keyboard.nextFloat();
   System.out.print ("Enter the gallons used in the third hour: ");
      float answer6 = keyboard.nextFloat();
   
   System.out.print ("\nEnter the miles driven in the fourth hour: ");
      float answer7 = keyboard.nextFloat();
   System.out.print ("Enter the gallons used in the fourth hour: ");
      float answer8 = keyboard.nextFloat();
   
   System.out.print ("\nEnter the miles driven in the fifth hour: ");
      float answer9 = keyboard.nextFloat();
   System.out.print ("Enter the gallons used in the fifth hour: ");
      float answer10 = keyboard.nextFloat();
      
  //Calculations of MPG
      float result1 = answer1 / answer2;
      float result2 = answer3 / answer4;
      float result3 = answer5 / answer6;
      float result4 = answer7 / answer8;
      float result5 = answer9 / answer10;
      
  //Calculations of TM, Overall MPG, Average MPH
      float result6 = answer1 + answer3+ answer5 + answer7 +answer9;
      float result7 = result6 / (answer2 + answer4 + answer6 + answer8 +answer10);
      float result8 = result6 / 5;
      
  //Statements
    System.out.println ("\nHour\tMiles\tGas\tMiles Per");
    System.out.println ("#\tDriven\tUsed\tGallon");
    System.out.println ("1\t" +answer1+ "\t" +answer2+ "\t" +result1);
    System.out.println ("2\t" +answer3+ "\t" +answer4+ "\t" +result2);
    System.out.println ("3\t" +answer5+ "\t" +answer6+ "\t" +result3);
    System.out.println ("4\t" +answer7+ "\t" +answer8+ "\t" +result4);
    System.out.println ("5\t" +answer9+ "\t" +answer10+ "\t" +result5);
    
    System.out.println ("\nTotal Miles:  " +result6);
    System.out.println ("Overall MPG:  " +result7); 
    System.out.println ("Average MPH:  " +result8);
    
    }//end of main method
 }//end of class GasMileage
      
   
   