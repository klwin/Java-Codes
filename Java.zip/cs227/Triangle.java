public class Triangle{
    public static void main(String [] args){
        StdDraw.square(.2,.8,.4);
    }
}