public class Experiments {
    public static void main(String [] args){
        System.out.println("what is up");
    }
}

    