public class Superhero { //start of class
   //set the informations to private 
   private String myName; 
   private String mySecretIdentity;
   private int myNumPowers;
   private String myMainColor;
   private String mySupportColor;
   private boolean myWearsCape;

   public Superhero(String name, String secretIdentity, int numPowers) { //constructor
      //calling the methods
      setName(name); 
      setSecretIdentity(secretIdentity);
      setNumPowers(numPowers);
      setMainColor("Red");
      setSupportColor("Yellow");
      setWearsCape(false);
      
   }

   public Superhero(String name, String secretIdentity, int numPowers,
   		String mainColor, String supportColor, boolean wearsCape) { //constructor
            //calling the methods
            setName(name); 
            setSecretIdentity(secretIdentity);
            setNumPowers(numPowers);
            setMainColor(mainColor);
            setSupportColor(supportColor);
            setWearsCape(wearsCape);
   
   }

	/*
	 * Set methods
	 */
    
/*---------------------------------------------------------------------
 |  Method name:    [setName]
 |  Purpose:  	    [Setting the name of the super hero]
 |  Pre-condition:  [Needs to be first and last name ]
 |  Parameters:     [String name, used for setting the value for myName]
 |  Returns:  	    [Nothing]
 *-------------------------------------------------------------------*/
   public void setName(String name) {
      myName = name;
      String space = " ";
      if (myName.indexOf(space)== -1) {
         myName = "John Doe";
      }
   
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [setSecretIdentity]
 |  Purpose:  	    [Set the hero's secret identity]
 |  Pre-condition:  [The first letter or the secret identity can't be the same as first letter of the hero's name]
 |  Parameters:     [String secretIdentity, used for setting the value for mySecretIdentity]
 |  Returns:  	    [Nothing]
 *-------------------------------------------------------------------*/

   public void setSecretIdentity(String secretIdentity) {
      mySecretIdentity = secretIdentity;
      String firstLetterOfSecret = mySecretIdentity.substring(0,1);
      String firstLetterOfName = myName.substring(0,1);
      
      if (firstLetterOfSecret.equalsIgnoreCase(firstLetterOfName)){
         mySecretIdentity = "Super Awesome Hero";
      }
   
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [setNumPowers]
 |  Purpose:  	    [Set the hero's number of powers]
 |  Pre-condition:  [Number of powers can't be less than 1]
 |  Parameters:     [int numPowers, used for setting the value for mynumPowers]
 |  Returns:  	    [Nothing]
 *-------------------------------------------------------------------*/

   public void setNumPowers(int numPowers) {
      myNumPowers = numPowers;
      
      if (myNumPowers < 1){
         myNumPowers = 1;
      }
   
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [setMainColor]
 |  Purpose:  	    [Set the main color of the costume]
 |  Pre-condition:  [It can only be blue, gold, silver, and red]
 |  Parameters:     [String mainColor, used for setting the value for myMainColor]
 |  Returns:  	    [Nothing]
 *-------------------------------------------------------------------*/

   public void setMainColor(String mainColor) {
      myMainColor = mainColor;
      String color1 = "Blue";
      String color2 = "Gold";
      String color3 = "Silver";
      String color4 = "Red";
   
      if (!(myMainColor.equals(color1) || myMainColor.equals(color2) || myMainColor.equals(color3))){
         myMainColor = color4;
      }
   
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [setSupportColor]
 |  Purpose:  	    [Set the support color of the costume]
 |  Pre-condition:  [It can only be black, maroon, green, white, and yellow]
 |  Parameters:     [String supportColor, used for setting the value for mySupportColor]
 |  Returns:  	    [Nothing]
 *-------------------------------------------------------------------*/

   public void setSupportColor(String supportColor) {
      mySupportColor = supportColor;
      String color1 = "Black";
      String color2 = "Maroon";
      String color3 = "Green";
      String color4 = "White";
      String color5 = "Yellow";
      
      if (!(mySupportColor.equals(color1) || mySupportColor.equals(color2) || mySupportColor.equals(color3) ||
         mySupportColor.equals(color4))){
            mySupportColor = color5;
      }
      
      
   
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [setWearsCape]
 |  Purpose:  	    [Set the costume with no cape]
 |  Pre-condition:  [The costume will have no cape]
 |  Parameters:     [boolean wearsCape, used for setting the value for myWearsCape to false]
 |  Returns:  	    [boolean false, means no cape]
 *-------------------------------------------------------------------*/

   public String setWearsCape(boolean wearsCape) {
   
      if(wearsCape == true){
         return "No Capes!";
      }
         return "";
         
   }

	/*
	 * Get Methods
	 */
   
   /*---------------------------------------------------------------------
 |  Method name:    [getName]
 |  Purpose:  	    [Get the hero's name from setName]
 |  Pre-condition:  [The myName is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [String myName, represent hero's name]
 *-------------------------------------------------------------------*/
 
   public String getName() {
      return myName;
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [getSecretIdentity]
 |  Purpose:  	    [Get the hero's secret identity]
 |  Pre-condition:  [The mySecretIdentity is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [String mySecretIdentity, represent hero's secret identity]
 *-------------------------------------------------------------------*/

   public String getSecretIdentity() {
      return mySecretIdentity;
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [getNumPowers]
 |  Purpose:  	    [Get hero's number of powers]
 |  Pre-condition:  [The myNumPowers is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [int myNumPowers, represents hero's number of powers]
 *-------------------------------------------------------------------*/

   public int getNumPowers() {
      return myNumPowers;
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [getMainColor]
 |  Purpose:  	    [Get hero's main color of the costume]
 |  Pre-condition:  [The myMainColor is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [String myMainColor, represents hero's main color of costume]
 *-------------------------------------------------------------------*/

   public String getMainColor() {
      return myMainColor;
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [getSupportColor]
 |  Purpose:  	    [Get the support color of the costume]
 |  Pre-condition:  [The mySupportColor is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [String mySupportColor, represents hero's support color of costume]
 *-------------------------------------------------------------------*/

   public String getSupportColor() {
      return mySupportColor;
   }
   
   /*---------------------------------------------------------------------
 |  Method name:    [getWearsCape]
 |  Purpose:  	    [Get if the hero's costume has cape or not]
 |  Pre-condition:  [The myWearsCape is set]
 |  Parameters:     [Nothing]
 |  Returns:  	    [boolean getWearsCape, represents if the hero wears cape or not]
 *-------------------------------------------------------------------*/

   public boolean getWearsCape() {
      return false;
   }
}//end of class