/*
 Name: Kaung Lwin
 NetID: klwin
 SectionNumber: 1D
 Description: Converts RGB to CMYK colors.
*/

public class RGBtoCMYK { //start of class
    public static void main(String [] args) { //start of main method
        //takes args
        double red = Double.parseDouble(args [0]);
        double green = Double.parseDouble(args [1]);
        double blue = Double.parseDouble(args [2]);
        //set white value
        double greater = Math.max(red, green);
        double greatest = Math.max(greater, blue);
        double white = greatest/255;
        //equations
        double cyan = (white - (red / 255)) / white;
        double magenta = (white - (green / 255)) / white;
        double yellow = (white - (blue / 255)) / white;
        double black = (1 - white); 
        //exception for when white is 0
        if (white == 0) {
            cyan = 0;
            magenta = 0;
            yellow = 0;
        }
        //print statements
        System.out.println("red \t = " + (int) red);
        System.out.println("green \t = " + (int) green);
        System.out.println("blue \t = " + (int) blue);
        System.out.println("cyan \t = " + cyan);
        System.out.println("magenta  = " + magenta);
        System.out.println("yellow \t = " + yellow);
        System.out.println("black \t = " + black);
    } //end of main method
} //end of class