public class Deck{
    public static void main(String [] args){
        String [] suit = { "Clubs", "Diamonds", "Hearts", "Spades" };
        String [] rank = { "2", "3", "4", "5", "6", "7", "8", "9", 
            "10", "Jack", "Queen", "King", "Ace" };
        int numSUITS = suit.length;
        int numRANKS = rank.length;
        int N = numSUITS * numRANKS;
        
//build the deck
        String [] deck = new String [N];
        for(int i = 0; i < numRANKS; i++){
            for(int j = 0; j < numSUITS; j++){
                deck[numSUITS*i + j] = rank[i] + " of " + suit[j];
            }
        }
        
//shuffle              
         for(int i = 0; i < N; i++){
             int r = i + (int) (Math.random() * (N-i));
             String t = deck[r];
             deck[r] = deck[i];
             deck[i] = t;
         }
         
//print shuffled deck        
         for(int i = 0; i < N; i++){
             System.out.println(deck[i]);
         }
    }
}
                    