/*
   Assignment: * Figures
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: April, 2, 9:00pm
   
   Description: Scan the input of user and create a box.  
   Deficiencies: None
   */

public class Figures {
	
	/*---------------------------------------------------------------------
	 |  Method name:	drawLine
	 |
	 |  Purpose:  	    This method takes in an integer which represents the size
	 |					of the line we wish to draw.  We will surround this line
	 |					with '+'s for the corners.  We use this method to print the
	 |					top and bottom borders of our shapes.
	 |
	 |  Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
	 |
	 |  Returns:  	    drawLine returns the top/bottom border of a shape formatted in the
	 |					following manner: a '+' followed by aSize number of '-'s, then a '+'
	 *-------------------------------------------------------------------*/
   
   public String drawLine(int aSize) {
      String line1 = "";
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      
      for (int x = 0; x < aSize; x++) { //start of drawLine loop
         line1 += '-';
      }
      
      return "+" +line1+ "+";
   }
   
    /*-----------------------------------------------------------------------------
	 |  Method name:	drawSolidSquare
	 |
	 |  Purpose:  	    This method takes takes two parameters: one an int and a fill char
    |					of the line we wish to draw. It will return a square (without a top/bottom border) 
    |             filled with the fill char. 
    |
	 |Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't. Also we
    |             need to check if its exclusively to * and Upper/Lower case letters, if not
    |             default will be W.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
    |                  aChar -- a char representing our character
	 |
	 |  Returns:  	    drawSolidSquare return a square (without a top/bottom border)
	 |					filled with the fill char.
	 *-------------------------------------------------------------------*/
    
   public String drawSolidSquare(int aSize, char aChar) {
      String lines = "";
      String line = "";
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      if (aChar != '*' && (!((aChar >= 'A' && aChar <= 'Z') || (aChar >= 'a' && aChar <= 'z')))){ //restriction
         aChar = 'W';
      }
      
      for (int i = 0; i < aSize; i++) { //start of solidSquare loop
         line += aChar;
      }
      for (int i = 0; i < aSize; i++) {
         lines += "|"+line+"|\n";
      }
      
      return lines;
   }

    /*-----------------------------------------------------------------------------
	 |  Method name:	drawEmptySquare
	 |
	 |  Purpose:  	    This method takes takes in an integer which represents the size
	 |					of the line we wish to draw.It returns a square (without a top/bottom border) 
    |             filled with spaces. 
    |
	 |Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't.
    | 	 
    |  Parameters:     aSize -- an integer representing the size of our shape
	 |
	 |  Returns:  	    drawSolidSquare will return a square (without a top/bottom border) filled with spaces.
	 *-------------------------------------------------------------------*/
    
   public String drawEmptySquare(int aSize) {
      String lines = "";
      String line = "";
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      
      for (int i = 0; i < aSize; i++) { //start of emptySquare loop
         line += " ";
      }
      for (int i = 0; i < aSize; i++) {
         lines += "|"+line+"|\n";
      }
      
      return lines;
   }

	
    /*---------------------------------------------------------------------
	 |  Method name:	drawUpTriangle
	 |
	 |  Purpose:  	   This method will take two parameters in this order: the size of the triangle 
    |             and the fill char.The size represents the maximum number of fill chars in the base (first row) 
    |             of the triangle. An upper triangle is a right triangle whose hypotenuse (longest side) runs from 
    |             the top right corner 
    |             to the bottom left.
	 |
	 |  Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't. Also we
    |             need to check if its only exclusively to * and Upper/Lower case letters, if not the
    |             default will be W.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
    |                  aChar -- a char representing our character
	 |
	 |  Returns:  	    drawUpTriangle return an upper triangle without a top or bottom border filled with the fill 
    |             char.  
    |
	 *-------------------------------------------------------------------*/
    
   public String drawUpTriangle(int aSize, char aChar) {
      String line = "";
      String line1 = " ";
      String line2 = "";
      
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      int holder = aSize;
      
      if (aChar != '*' && (!((aChar >= 'A' && aChar <= 'Z') || (aChar >= 'a' && aChar <= 'z')))){ //restriction
         aChar = 'W';
      }
      
      for (int i = 0; i < aSize; i++){ //start of drawUpTriangle loop
         line += "|";
         for (int y = 0; y < holder; y++){
            line += aChar; 
         }
         for(int x = 0; x < aSize-holder; x++){
            line += line1; //add empty spaces
         }
         line += "|";
         line += "\n";     
         holder--;
      }
      
      return line;
   }

    /*---------------------------------------------------------------------
	 |  Method name:	drawDownTriangle
	 |
	 |  Purpose:  	   This method will take two parameters in this order: the size of the triangle 
    |             and the fill char.The size represents the maximum number of fill chars in the base (bottom row) 
    |             of the triangle. A lower triangle is a right triangle whose hypotenuse (longest side) runs from 
    |             the top left corner to the bottom left.
	 |
	 |  Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't. Also we
    |             need to check if its only exclusively to * and Upper/Lower case letters, if not the
    |             default will be W.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
    |                  aChar -- a char representing our character
	 |
	 |  Returns:  	    drawDownTriangle return a lower triangle without a top or bottom border filled with the fill 
    |             char.  
    |
	 *-------------------------------------------------------------------*/
    
   public String drawDownTriangle(int aSize, char aChar) {
      String line = "";
      String line1 = " ";
      
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      
      int holder = aSize-1;
      
      if (aChar != '*' && (!((aChar >= 'A' && aChar <= 'Z') || (aChar >= 'a' && aChar <= 'z')))){ //restriction
         aChar = 'W';
      }
      
      for(int x = 0; x < aSize; x++){ //start of drawDownTriangle loop
         line += "|";
         for(int i = 0; i < aSize-holder; i++){
            line += aChar;
         }
         for(int y = 0; y < holder; y++){
            line += line1; //add empty spaces  
         } 
         holder--;
         line += "|";
         line += "\n";
      }
      
      return line;
   }
   
    /*---------------------------------------------------------------------
	 |  Method name:	drawDiagonal
	 |
	 |  Purpose:  	   This method will take two parameters in this order: the size of the triangle 
    |             and the fill char.It will return a square without a top or bottom border, containing a diagonal,
    |              made of fill chars, that runs from the top left to the bottom right. 
    |
	 |  Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't. Also we
    |             need to check if its only exclusively to * and Upper/Lower case letters, if not the
    |             default will be W.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
    |                  aChar -- a char representing our character
	 |
	 |  Returns:  	    drawUpTriangle return a square without a top or bottom border, containing a diagonal,
    |              made of fill chars, that runs from the top left to the bottom right.    
	 *-------------------------------------------------------------------*/
   
   public String drawDiagonal(int aSize, char aChar) {
      String line = "";
      String line1 = " ";
      String line2 = " ";
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      
      int holder = aSize-1;
      int holder1 = aSize;
      
      if (aChar != '*' && (!((aChar >= 'A' && aChar <= 'Z') || (aChar >= 'a' && aChar <= 'z')))){ //restriction
         aChar = 'W';
      }
      
      for(int x = 0; x < aSize; x++){  //start of drawDiagonal loop
         line += "|";
         for(int z = 0; z < aSize-holder1; z++){
            line += line2;
         }
         line += aChar;
         for(int y = 0; y < holder; y++){
            line += line1; //add empty spaces  
         } 
         holder--;
         holder1--;
         line += "|";
         line += "\n";
      }
      
      return line;
   }

    /*---------------------------------------------------------------------
	 |  Method name:	drawPennant
	 |
	 |  Purpose:  	   This method will take two parameters in this order: the size of the triangle 
    |              and the fill char.It will return a pennant without a top or bottom border that is filled
    |              with the fill char. 
    |
	 |  Pre-condition:  Nothing.  The size can be any integer.  We will need to check
	 |					that it is between 0 and 80 inclusive and default to 5 if it isn't. Also we
    |             need to check if its only exclusively to * and Upper/Lower case letters, if not the
    |             default will be W.
	 |
	 |  Parameters:     aSize -- an integer representing the size of our shape
    |                  aChar -- a char representing our character
	 |
	 |  Returns:  	    drawUpTriangle returns a pennant without a top or bottom border that is filled
    |              with the fill char.    
	 *-------------------------------------------------------------------*/
   public String drawPennant(int aSize, char aChar) {
      String line = "";
      String line1 = " ";
      String line2 = "";
      
      if (aSize < 0 || aSize > 80){ //restriction
         aSize = 5;
      }
      
      int holder = aSize;
      int holder1 = aSize-1;
      
      if (aChar != '*' && (!((aChar >= 'A' && aChar <= 'Z') || (aChar >= 'a' && aChar <= 'z')))){ //restriction
         aChar = 'W';
      }
      
      for (int i = 0; i < aSize; i++){ //first part of pennant loop
         line += "|";
         for (int y = 0; y < holder; y++){
            line += aChar; 
         }
         for(int x = 0; x < aSize-holder; x++){
            line += line1; //add empty spaces
         }
         line += "|";
         line += "\n";     
         holder--;
      }
      for(int x = 0; x < aSize; x++){ //second part of pennant loop
         line += "|";
         for(int i = 0; i < aSize-holder1; i++){
            line += aChar;
         }
         for(int y = 0; y < holder1; y++){
            line += line1; //add empty spaces  
         } 
         holder1--;
         line += "|";
         line += "\n";
      }
      
      return line;
   }
}