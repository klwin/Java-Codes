/*
 Name: Kaung Lwin
 NetID: klwin
 SectionNumber: 1D
 Description: Prints out "Hello, World"
*/


public class HelloWorld { //start of class
    public static void main(String [] args) { //start of main arg
        System.out.println("Hello, World"); //prints "hello world"
    } // end of main arg
} //end of class