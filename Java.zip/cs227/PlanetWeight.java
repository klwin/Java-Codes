/*
   Assignment: #2 PlanetWeight
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: rvyn Abraham
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 5 9:00pm
   
   Description: Calculate your weight in serval places of the solar system.
   
   Deficiencies: 
   */
   
   
   public class PlanetWeight //start of main method
   {
      public static void main ( String args[] ){
         float kerbin = 32.2F ;
         float mun = 5.348F ;
         float duna = 9.646F ;
         float ike = 3.609F ;
         float laythe = 25.754F ;
         float gilly = 0.16076F ;
         float spacecraftWeight = 11000F ;
         float jebWeight = 70.55F ;
         
 //Calculations
   float weightOnKerbin = ( kerbin / kerbin ) * ( jebWeight + spacecraftWeight );
   float weightOnMun = ( mun / kerbin ) * ( jebWeight + spacecraftWeight );
   float weightOnDuna = ( duna / kerbin ) * (jebWeight + spacecraftWeight );
   float weightOnIke = ( ike / kerbin ) * ( jebWeight + spacecraftWeight );
   float weightOnLaythe = ( laythe / kerbin ) * ( jebWeight + spacecraftWeight );
   float weightOnGilly = (gilly / kerbin ) * ( jebWeight + spacecraftWeight );
   
   
      System.out.println ("Jeb's Weight on Kerbin is:\t" + jebWeight + " pounds");
      System.out.println ("Total Weight on Kerbin is:\t" + weightOnKerbin + " pounds");
     
      System.out.println ("\nJeb's Weight on Mun is:\t\t" + jebWeight * ( mun / kerbin ) + " pounds");// \n creates new line
      System.out.println ("Total Weight on Mun is:\t\t" + weightOnMun + " pounds");
      System.out.println ("Jeb's Weight on Duna is:\t" + jebWeight * ( duna / kerbin ) + " pounds");
      System.out.println ("Total Weight on Duna is:\t" + weightOnDuna + " pounds");
      System.out.println ("Jeb's Weight on Ike is:\t\t" + jebWeight * ( ike / kerbin ) + " pounds");
      System.out.println ("Total Weight on Ike is:\t\t" + weightOnIke + " pounds");
      System.out.println ("Jeb's Weight on Laythe is:\t" + jebWeight * ( laythe / kerbin ) + " pounds");
      System.out.println ("Total Weight on Laythe is:\t" + weightOnLaythe + " pounds");
      System.out.println ("Jeb's Weight on Gilly is:\t" + jebWeight * ( gilly / kerbin ) + " pounds");
      System.out.println ("Total Weight on Gilly is:\t" + weightOnGilly + " pounds");
      

      
      
 
    
} // end of main method
   } //end of class
   