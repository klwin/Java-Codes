  /*
   Assignment: MathMindTrick
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham   
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 19 9:00pm
   
   Description: The program will run some tricks of algebraic manipulation.
   
   Deficiencies: No deficiencies
   */
   import java.util.Scanner;
   import java.util.Random;
   public class MathMindTricks { //start of main method
      public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   System.out.print("Please enter a seed: ");
   long seed = keyboard.nextLong();
   Random randomNumber = new Random(+seed);//Implements a seed
   
   int randomNumber1 = randomNumber.nextInt(10-0) + 1;//Generate a random number b/t 1 to 10
   System.out.print("\nGenerate a random number between 1 and 10: " + randomNumber1 );
   int multiplyBy9 = randomNumber1 * 9;
   System.out.print("\nMultiply it by nine: " + multiplyBy9);
   int firstDigitOfrandomNumber1 = multiplyBy9 / 10;//Get the first digit of multiply by 9
   int lastDigitOfrandomNumber1 = multiplyBy9 % 10;//Get the last digit of multiply by 9
   int addDigitsOfResult = firstDigitOfrandomNumber1 + lastDigitOfrandomNumber1;
   System.out.print("\nAdd the digits of the result together: " + addDigitsOfResult);
   int add4Result = addDigitsOfResult + 4;
   System.out.print("\nAdd four to your result: " + add4Result);
   
   System.out.print("\n\nYou should get 13!");
   
   int randomNumber2 = randomNumber.nextInt(900) + 100;//Generate a random number b/t 100-999
   System.out.print("\n\nGenerate a random three digit number: " + randomNumber2);
   int multiplyBy80 = randomNumber2 * 80;
   System.out.print("\nMultiply it by 80: " + multiplyBy80);
   int add1 = multiplyBy80 + 1;
   System.out.print("\nAdd one to the result: " + add1);
   int multiplyBy250 = add1 * 250;
   System.out.print("\nMultiply the result by 250: " + multiplyBy250);
   int randomNumber3 = randomNumber.nextInt(9000) + 1000;//Generate a random number b/t 1000 to 9999
   System.out.print("\nGenerate a random four digit number: " + randomNumber3);
   int addRandomNumber3ToMultiplyBy250 = randomNumber3 + multiplyBy250;
   System.out.print("\nAdd the four digit number to your result: " + addRandomNumber3ToMultiplyBy250);
   int addRandomNumber3ToMultiplyBy250Twice = addRandomNumber3ToMultiplyBy250 + randomNumber3;
   System.out.print("\nAdd the four digit number to your result again: " + addRandomNumber3ToMultiplyBy250Twice);
   int subtract250 = addRandomNumber3ToMultiplyBy250Twice - 250;
   System.out.print("\nSubtract 250 from your result: " + subtract250);
   int divideBy2 = subtract250 / 2;
   System.out.print("\nDivide the result by two: " + divideBy2);
   
   System.out.print("\n\nDoes that look familiar?");
   
   System.out.print("\n\nGenerate a random three digit number where the first digit and\n   the last digit differ by at least 2:");
   
   int randomNumber4 = randomNumber.nextInt(900) + 100;//Generate a random number b/t 100-999
   System.out.print("\n\nBase three digit number: " + randomNumber4);
   int firstDigitOfRandomNumber4 = (randomNumber4 / 100);//Get 1st digit of random number4
   System.out.print("\nFirst digit: " + firstDigitOfRandomNumber4);
   int add3 = (firstDigitOfRandomNumber4 + 3);
   System.out.print("\nAdd three to the first digit: " + add3);
   int secondDigitOfRandomNumber4 = (randomNumber4 % 100) / 10;//Get 2nd digit of random number 4
   int lastDigitOfRandomNumber4 = (randomNumber4 % 10);//get last digit of random number 4
   System.out.print("\nCurrent last digit: " + lastDigitOfRandomNumber4);
   System.out.print("\nNew last digit: " + add3 % 10); 
   int firstThreeDigits = firstDigitOfRandomNumber4 * 100;
   int secondThreeDigits = secondDigitOfRandomNumber4 * 10;
   int thirdThreeDigits = add3 % 10;
   int threeDigits = firstThreeDigits + secondThreeDigits + thirdThreeDigits;//replaced with new digit from add3
   System.out.print("\nNew three digit number: " + threeDigits);
   
   System.out.print("\n\nNow for the final trick: ");
   int firstDigitOfReversed = (add3 % 10) * 100;//Get reversed 1st digit
   int secondDigitOfReversed = secondDigitOfRandomNumber4 * 10;//Get reversed 2nd digit
   int lastDigitOfReversed = firstDigitOfRandomNumber4;//Get reversed 3rd digit
   int digitsReversed = firstDigitOfReversed + secondDigitOfReversed + lastDigitOfReversed;
   System.out.print("\nNew three digit number reversed: " + digitsReversed);
   int subtractThreeFromReversed = Math.abs(digitsReversed - threeDigits);//Takes the abs value
   System.out.print("\nTake the three digit number you built and the result of reversing\n   it. Subtract the smaller of the two from the larger: " + subtractThreeFromReversed);
   int firstSubReversed = (subtractThreeFromReversed % 10) * 100;//Get reversed sub 1st digit
   int secondSubReversed = ((subtractThreeFromReversed % 100) / 10) * 10;//Get reversed sub 2nd digit
   int lastSubReversed = (subtractThreeFromReversed / 100);//Get reversed sub 3rd digit
   int reversedSubtraction = firstSubReversed + secondSubReversed + lastSubReversed;
   System.out.print("\nNow reverse the result of that subtraction: " + reversedSubtraction);
   int addReversedAndSubtractThreeFromReversed = reversedSubtraction + subtractThreeFromReversed;
   System.out.print("\nNow add the number you got from the subtraction to the number you\n   just created: " + addReversedAndSubtractThreeFromReversed);
   
   System.out.print("\n\nYour number is " + addReversedAndSubtractThreeFromReversed + "!");
   
   
   
   
   
 
  
   
   }//end of main method
      }//end of class
