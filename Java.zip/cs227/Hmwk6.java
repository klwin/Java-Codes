/*=============================================================================
 |   Assignment:  Homework #6:  [Assignment Title]
 |       Author:  [Kaung Lwin (klwin@email.arizona.edu)]
 |       Grader:  [Brandon]
 |
 |       Course:  [Cs 245]
 |   Instructor:  L. McCann
 |     Due Date:  [April, 10, 2015]
 |
 |  Description:  [Creating and (Lightly) Testing a Linear Congruential 
 |                 Pseudo-Random Number Generator]
 |                
 | Deficiencies:  [V values are a little off]
 *===========================================================================*/
import java.text.DecimalFormat;

public class Hmwk6 {
    /*---------------------------------------------------------------------
        |  Method [Main]
        |
        |  Purpose:  [Prints the strings and values for the programs, starts
        |      the program]
        |
        |  Pre-condition:  [All other methods need to be functioning 
        |      correctly]
        |
        |  Post-condition: [All methods are working properly]
        |
        |  Parameters:
        |      parameter_name -- [None]
        |
        |  Returns:  [None]
        *-------------------------------------------------------------------*/
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#,###,##0.0000"); //Setup display format
        int a = Integer.parseInt(args[0]);// takes in arguments from user
        int c = Integer.parseInt(args[1]);
        int m = Integer.parseInt(args[2]);
        int x = Integer.parseInt(args[3]);
        int n = Integer.parseInt(args[4]);
        
       //if statements for SOP
        if(a > 0 && c > 0) {
            if(getMax(a, c, x) < m){
                if(relativePrime(c,m)){
                    System.out.println("Conditions satisfied");
                } 
            }
        }
        
         if(!(a > 0 && c > 0)) {
             System.out.println("Condition 1 not satisfied");
         }
         if(!(getMax(a, c, x) < m)){
             System.out.println("Condition 2 not satisfied");
         }
         if(!(relativePrime(c,m))){
             System.out.println("Condition 3 not satisfied");
         }
         
         System.out.println("V = " + df.format(computeV(a, c, m, n, x)) + "; " + 
                           state(computeV(a, c, m, n, x)));
    }
    /*---------------------------------------------------------------------
        |  Method [getMax]
        |
        |  Purpose:  [Get the max of three numbers]
        |
        |  Pre-condition:  [need the 3 numbers to exist]
        |
        |  Post-condition: [It will find a largest number]
        |
        |  Parameters:
        |      parameter_name -- [need int a,c,x so it can find the largest
        |      number]
        |
        |  Returns:  [an int largest number]
        *-------------------------------------------------------------------*/
    private static int getMax(int a, int c , int x) {
        if(a > c && a > x) {
            return a;
        }
        if(c > x && c > a) {
            return c;
        }
        return x;
    }
    /*---------------------------------------------------------------------
        |  Method [gcd]
        |
        |  Purpose:  [finds the greatest common divisor]
        |
        |  Pre-condition:  [needs two int inputs]
        |
        |  Post-condition: [it will find a gcd of two inputs]
        |
        |  Parameters:
        |      parameter_name -- [int c and int m which are two inputs]
        |
        |  Returns:  [int number which is a gcd of the two inputs]
        *-------------------------------------------------------------------*/
    private static int gcd(int c, int m) {
        int t;
        while(m != 0) { //Euclidean algorithm for calculating the GCD
            t = c;
            c = m;
            m = t % m;
        }
        return c;
    }
    /*---------------------------------------------------------------------
        |  Method [relativePrime]
        |
        |  Purpose:  [determines if the two numbers are relative prime]
        |
        |  Pre-condition:  [needs gcd of two inputs]
        |
        |  Post-condition: [gcd is working properly and will produce a boolean]
        |
        |  Parameters:
        |      parameter_name -- [need two input of int c, int m]
        |
        |  Returns:  [boolean which says if it's relative prime or not]
        *-------------------------------------------------------------------*/
    private static boolean relativePrime(int c, int m) {
        return gcd(c, m) == 1; //see if its relative prime
    }
    /*---------------------------------------------------------------------
        |  Method [computeV]
        |
        |  Purpose:  [Compute V]
        |
        |  Pre-condition:  [need 5 inputs]
        |
        |  Post-condition: [will give you the uniformity value]
        |
        |  Parameters:
        |      parameter_name -- [5 int inputs a, c, m, n, x]
        |
        |  Returns:  [the double V value]
        *-------------------------------------------------------------------*/
    private static double computeV(int a, int c, int m, int n, int x) {
        double a1 = 0; //initialize the 10 ranges
        double a2 = 0;
        double a3 = 0;
        double a4 = 0;
        double a5 = 0;
        double a6 = 0;
        double a7 = 0;
        double a8 = 0;
        double a9 = 0;
        double a10= 0;
        double t2 = (double) m/10; // needed for ranges
        double t3; // will be use to determine if its 0.01 or 1
        double t4 = n/10; //needed to compute V value
        double t = x; //temporary holder for x
        double t1; //temporary holder for t
        if(m < 100) { //if t3 is 0.01 or 1
            t3 = 0.1;
        }
        else {
            t3 = 1;
        }
        for(int i = 0; i < n; i++) { // the loop for the 10 ranges
            t1 = (a * (t + c)) % m;
            t = t1;
            
            
            if(t1 >= 0 && (t1 <= t2 - t3)){
                a1++;
            }
            if(t1 >= t2 && (t1 <= (2*t2) - t3)){
                a2++;  
            }
            if(t1 >= (2*t2) && (t1 <= (3*t2) - t3)){
                a3++;
            }
            if(t1 >= (3*t2) && (t1 <= (4*t2) - t3)){
                a4++;
            }
            if(t1 >= (4*t2) && (t1 <= (5*t2) - t3)){
                a5++;
            }
            if(t1 >= (5*t2) && (t1 <= (6*t2) - t3)){
                a6++;
            }
            if(t1 >= (6*t2) && (t1 <= (7*t2) - t3)){
                a7++;
            }
            if(t1 >= (7*t2) && (t1 <= (8*t2) - t3)){
                a8++;
            }
            if(t1 >= (8*t2) && (t1 <= (9*t2) - t3)){
                a9++;
            }
            if(t1 >= (9*t2) && (t1 <= (10*t2) - t3)){
                a10++;
            }
        }
        a1 = (a1-t4) * (a1-t4); //More math to compute V value
        a2 = (a2-t4) * (a2-t4);
        a3 = (a3-t4) * (a3-t4);
        a4 = (a4-t4) * (a4-t4);
        a5 = (a5-t4) * (a5-t4);
        a6 = (a6-t4) * (a6-t4);
        a7 = (a7-t4) * (a7-t4);
        a8 = (a8-t4) * (a8-t4);
        a9 = (a9-t4) * (a9-t4);
        a10 = (a10-t4) * (a10-t4);
            
        return (a1/t4) + (a2/t4) + (a3/t4) + (a4/t4) + (a5/t4) + (a6/t4) + (a7/t4)
            + (a8/t4) + (a9/t4) + (a10/t4);
    }
    /*---------------------------------------------------------------------
        |  Method [state]
        |
        |  Purpose:  [determine the state of the V value; ok, rejected, suspicious]
        |
        |  Pre-condition:  [Need V value to already be computed]
        |
        |  Post-condition: [Will give you one of the 3 states listed above]
        |
        |  Parameters:
        |      parameter_name -- [double V]
        |
        |  Returns:  [String of the 3 states listed above]
        *-------------------------------------------------------------------*/
    private static String state(double v) {
        //if statements for 3 state of the V value and return accordingly
        if(v < 2.088 || v > 21.67) {
            return "this function is rejected";
        }
        if(v < 3.325 || v > 16.92) {
            return "this function is suspicious";
        }
        else {
            return "this function is ok";
        }
    }
    
}
        
                
        
        
            
        