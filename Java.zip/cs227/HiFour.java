/*
 Name: Kaung Lwin
 NetID: klwin
 SectionNumber: 1D
 Description: Prints out "Hi" with the 4 names in reverse order of user input
*/

public class HiFour { //start of class
    public static void main(String [] args) { //start of main arg
        System.out.print("Hi ");
        System.out.print(args[3]); //print the fourth arg 
        System.out.print(", " + args[2]); //print the third arg
        System.out.print(", " + args[1]); //print the second arg
        System.out.print(", and " + args[0] + ".\n"); //print the first arg
    } //end of main arg
} // end of class