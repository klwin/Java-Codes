   /*
   Assignment: GeneratePassword
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham   
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 19 9:00pm
   
   Description: The program will generate a random password out of random characters.
   
   Deficiencies: 
   */
   
   import java.util.Scanner;
   import java.util.Random;
   public class GeneratePassword { //start of main method
      public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   String list8Letters = "aardvark backflip captured carousel diatomic diamonds evermore fugitive gadgetry glittery hologram lynchpin nicknack ";
   String list5Letters = "after abyss brain clamp dives drain frost flame house joker kappa messy marty offal oxide panic puppy rough riots shiny toast whose "; 
   
   System.out.print("Enter a seed: ");
   long seed = keyboard.nextLong();
   Random randomNumber = new Random(+seed);//Implements a seed
   
   int randomNumberFor8Letters = randomNumber.nextInt(13 - 0) + 0;//Generate a random number for 8 letters
   int first8LetterOfTheWord = (9 * randomNumberFor8Letters);
   int last8LetterOfTheWord = ((9 * (randomNumberFor8Letters + 1)) - 1);
   
   String first8LetterWord = list8Letters.substring(first8LetterOfTheWord,last8LetterOfTheWord);
   System.out.print("\nFirst 8-letter word: '" + first8LetterWord + "'");//First 8 letter words
   
   int randomNumberForDigits = randomNumber.nextInt(10);//Generate a random number
   System.out.print("\nWith two digits: '" + first8LetterWord + randomNumberForDigits + randomNumberForDigits + "'");
   
   int randomNumberFor5Letters = randomNumber.nextInt(22 - 0) + 0;//Generate a random number for 5 letter words
   int first5LetterOfTheWord = (6 * randomNumberFor5Letters);
   int last5LetterOfTheWord = ((6 * (randomNumberFor5Letters + 1)) - 1);
   String first5LetterWord = list5Letters.substring(first5LetterOfTheWord,last5LetterOfTheWord);
   System.out.print("\n\nWith the 5-letter word: '" + first8LetterWord + randomNumberForDigits + randomNumberForDigits + first5LetterWord + "'");
   
   int randomNumberForSecondDigits = randomNumber.nextInt(10);//Generate a second random number
   System.out.print("\nWith two digits: '" + first8LetterWord + randomNumberForDigits + randomNumberForDigits + first5LetterWord + randomNumberForSecondDigits + randomNumberForSecondDigits + "'");
   
   String backwardFirst = first5LetterWord.substring(4,5);//Reversing the 5 letter word
   String backwardSecond = first5LetterWord.substring(3,4);
   String backwardThird = first5LetterWord.substring(2,3);
   String backwardFourth = first5LetterWord.substring(1,2);
   String backwardFifth = first5LetterWord.substring(0,1);
   String backwardFirst5LetterWord = backwardFirst+backwardSecond+backwardThird+backwardFourth+backwardFifth;
   System.out.print("\n\nWith the 5-letter word backwards: '" + first8LetterWord + randomNumberForDigits + 
   randomNumberForDigits + first5LetterWord + randomNumberForSecondDigits + randomNumberForSecondDigits + backwardFirst5LetterWord + "'");
   
   int randomNumberForThirdDigits = randomNumber.nextInt(10);//Generate a third random number
   System.out.print("\nWith two digits: '" + first8LetterWord +randomNumberForDigits + randomNumberForDigits + first5LetterWord + randomNumberForSecondDigits + randomNumberForSecondDigits + backwardFirst5LetterWord + randomNumberForThirdDigits + randomNumberForThirdDigits + "'");
   
   int randomNumberFor8Letters2 = randomNumber.nextInt(13 - 0) + 0;//Generate a random number for 8 letter words
   int first8LetterOfTheWord2 = (9 * randomNumberFor8Letters2);
   int last8LetterOfTheWord2 = (( 9 * (randomNumberFor8Letters2 + 1)) - 1);
   String second8LetterWord = list8Letters.substring(first8LetterOfTheWord2,last8LetterOfTheWord2);
   System.out.print("\n\nFinal password: '" + first8LetterWord +randomNumberForDigits + randomNumberForDigits + first5LetterWord + randomNumberForSecondDigits + randomNumberForSecondDigits + backwardFirst5LetterWord + randomNumberForThirdDigits + randomNumberForThirdDigits + second8LetterWord + "'");
   
   
  
   
   
   
  
   
   }//end of main method
      }//end of class
   