/**********************************************************************
 *  readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Name: Kaung Lwin

Arizona NetID: klwin

Section: 1D

Do you have a laptop you can bring to precept? yes

Operating System (e.g., Windows or OS X): Windows 8.1

Text editor (e.g., DrJava): DrJava

Hours to complete assignment (optional): 

Have you taken (part of) this course before: Yes 127A

/**********************************************************************
 *  List some information (optionally) to help your preceptor get
 *  to know you.
 **********************************************************************/

Nickname: Kaung

Year: Junior

Possible majors (if you know or have an idea): Computer Science

Confidence level (0 = very afraid, 5 = very confident): 4

Do you have any previous programming experience? Yes

Why are you interested in taking computer science? I love programming

What other interests do you have? Guitar

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy.
 *  Did you do this? 
 **********************************************************************/
 Yes


/**********************************************************************
 *  Did you receive help from classmates, past CS 227 students, or
 *  anyone else?  Please list their names.  ("A Monday lab TA" or 
 *  "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/
 No


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
 Nothing yet.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 Looking forward to an incredible year!