/*
   Assignment: Extra Credit
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: March, 26, 9:00pm
   
   Description: Scan the numbers and tell the largest numbers which then end with -1.  
   Deficiencies: None
   */
   
import java.util.Scanner;//import scanner

public class ThreeLargest//start of the main method
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
      
      //initialize variables
      int nonNegativeNumber = 0;
      int first = 0;
      int second = 0;
      int third = 0;
      int number;
      
      
      
      // create a loop to check all the numbers & if cases
      
      do{
         
         System.out.print("Enter an integer >= 0, use -1 to stop: ");
         number = keyboard.nextInt();
         
         if (number >= 0) {
            nonNegativeNumber++;
         }
         
         
         if (number > first) {
            third = second;
            second = first;
            first = number;
         }
         
         if (number > second && number < first) {
            third = second;
            second = number;
            
         }
         
            
         if (number > third && number < second) {
            third = number;
         }
              
         if (number == -1){
            break;
         }
      }while(number > -1 || number < -1);
      
      System.out.println();
      
      //Printing statements
      if (nonNegativeNumber > 1) {
         System.out.println (+ nonNegativeNumber + " non-negative numbers were entered.");
         System.out.println ("The largest number is " +first);
      }
      
      if (nonNegativeNumber == 1) {
         System.out.println (+ nonNegativeNumber + " non-negative number was entered.");
         System.out.println ("The largest number is " +first);
      }
      
      if (nonNegativeNumber == 0) {
         System.out.println ("No non-negative numbers were entered.");
      }
      
      if (first == second) {
         second = 0;
      }
      if (third == second) {
         third = 0;
      }
      
       
      
      if (second < first && second != 0){
         System.out.println("The second largest number is " + second);
      }
         
      if (third < second && third !=0) {
         System.out.println("The third largest number is " + third);
      }//end of while loop
   }//end of main
}//end of class
