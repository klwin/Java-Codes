/**********************************************************************
 *  readme template
 *  Loops
 **********************************************************************/

Name: Kaung Lwin
Login: klwin
Section: 1D
OS: Windows 8.1
Text editor: DrJava
Hours to complete assignment (optional): 4-5 hours

/**********************************************************************
 *  How does the mean squared distance of a random walker grow
 *  as a function of the number of steps N?  Briefly justify your
 *  answer based on computational experiments.  (Describe the 
 *  experiments and/or list several data points.)
 *********************************************************************/

If the amount of steps are larger, the mean squared distance will increase generally
as 1 to 1 ration. The amount of experiments prove the 1 to 1 raito better as we perform
more experiment. Here are sample data points (400, 2000) = 409.44 and (1600, 100000) = 1605.




/**********************************************************************
 *  Did you receive help from classmates, past CS 227 students, or
 *  anyone else?  Please list their names.  ("A Monday lab TA" or 
 *  "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

I received help from Thursday TA.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

No serious problems encountered.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

The assignment was fun and challanging!
