/*
   Assignment: #5 Language Parser
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Jeremy Mowery
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: March, 5 9:00pm
   
   Description: A program that will take the sentence and tell the user if that sentence is part of the ancientlanguage.   
   Deficiencies: None
   */
   import java.util.Scanner;
   import java.util.Random;
   public class LanguageParser { //start of main method
      public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   
   System.out.print("Enter a sentence: ");//have user input data
   String sentence = keyboard.nextLine();
   
   //picking the first, second, and third word of the string
   int indexOfSpace = sentence.indexOf (" ");
   String word1 = sentence.substring(0, indexOfSpace);
   String wordRest = sentence.substring(indexOfSpace+1, sentence.length());
   int indexOfSpace1 = wordRest.indexOf (" ");
   String word2 = wordRest.substring(0, indexOfSpace1);
   String word3 = wordRest.substring(indexOfSpace1+1, wordRest.length());
   
   //having and creating booleans to build flag for each words to match with the types of words
   String wordFirstSub = word1.substring (0,1);
   String wordSecondSub = word1.substring (word1.length()-1);
   boolean firstWordFlorb =(!wordFirstSub.equals(wordSecondSub));
   boolean firstWordWooble = (word1.contains("pq") || (word1.contains("zt")));
   String wordThirdSub = word1.substring (word1.length()/2, (word1.length()/2)+1);
   boolean firstWordZarf = (wordThirdSub.equals(wordThirdSub.toUpperCase()));
   
   boolean secondWordWooble = (word2.contains("pq") || (word2.contains("zt")));
   String wordFourthSub = word2.substring (word2.length()/2, (word2.length()/2)+1);
   boolean secondWordZarf = (wordFourthSub.equals(wordFourthSub.toUpperCase()));

   
   
   String wordFifthSub = word3.substring (0,1);
   String wordSixthSub = word3.substring (word3.length()-1);
   boolean thirdWordFlorb = (!wordFifthSub.equals(wordSixthSub));
   int wordMultipleOfThree = word3.length()%3;
   int wordMultipleOfFour = word3.length()%4;
   boolean thirdWordZith = ((wordMultipleOfThree == 0 || wordMultipleOfFour == 0) && word3.contains("j"));
   
   //having and creating rules and building flag to match each words with rules
   boolean rule1 = (firstWordFlorb && secondWordWooble && thirdWordZith);
   if (rule1 == true)
   {
   System.out.println("According to rule 1, the sentence '" +sentence+ "'\nis part of our language");
   }
   
   boolean rule2 = (firstWordZarf && secondWordWooble && thirdWordZith);
   if (rule2 == true)
   {
   System.out.println("According to rule 2, the sentence '" +sentence+ "'\nis part of our language");
   }
   
   boolean rule3 = (firstWordFlorb && secondWordZarf && thirdWordZith);
   if (rule3 == true)
   {
   System.out.println("According to rule 3, the sentence '" +sentence+ "'\nis part of our language");
   }
   
   boolean rule4 = (firstWordWooble && secondWordWooble && thirdWordZith);
   if (rule4 == true)
   {
   System.out.println("According to rule 4, the sentence '" +sentence+ "'\nis part of our language");
   }
   
   boolean rule5 = (firstWordFlorb && secondWordZarf && thirdWordFlorb);
   if (rule5 == true)
   {
   System.out.println("According to rule 5, the sentence '" +sentence+ "'\nis part of our language");
   }
   if ( !rule1 && !rule2 && !rule3 && !rule4 && !rule5)
   {
   System.out.println("According to our rules, the sentence '" +sentence+ "'\nis not part of our language");
   }
   
   }//end of main method
      }//end of class