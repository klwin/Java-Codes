/*
   Assignment: #5 Identify Word
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Jeremy Mowery
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: March, 5 9:00pm
   
   Description: Identify and states if the word contains a florb, a wooble, a zith, or a zarf.   
   Deficiencies: None
   */
   import java.util.Scanner;
   import java.util.Random;
   public class IdentifyWord { //start of main method
      public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   System.out.print("Please enter a word to be analyzed: ");
   String word = keyboard.next();
   
   String wordFirstSub = word.substring (0,1);
   String wordSecondSub = word.substring (word.length()-1);
   boolean florb = (!wordFirstSub.equals(wordSecondSub));
   if (florb == true){
   System.out.println("The word '" +word+ "' is a florb");
   }
   
   boolean wooble = (word.contains("pq") || (word.contains("zt")));
   if (wooble == true){
   System.out.println("The word '" +word+ "' is a wooble");
   }
   
   int wordMultipleOfThree = word.length()%3;
   int wordMultipleOfFour = word.length()%4;
   boolean zith = ((wordMultipleOfThree == 0 || wordMultipleOfFour == 0) && word.contains("j"));
   if (zith == true){
   System.out.println("The word '" +word+ "' is a zith");
   }
   
   String wordThirdSub = word.substring (word.length()/2, (word.length()/2)+1);
   boolean zarf = (wordThirdSub.equals(wordThirdSub.toUpperCase()));
   if (zarf == true){
   System.out.println("The word '" +word+ "' is a zarf");
   }
   if (!zarf && !zith && !wooble && !florb)
   {
   System.out.println("The word '" +word+ "' is not one of the four parts of speech");
   }
   
   }
      }
   
   
   