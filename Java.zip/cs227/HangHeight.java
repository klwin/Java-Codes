/*
   Assignment: #3 HangHeight 
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham
      
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 12 9:00pm
   
   Description: Calculate your weight in serval places of the solar system.
   
   Deficiencies: no deficiencies
   */
import java.util.Scanner;  
public class HangHeight {  // start of main method
   public static void main(String[]args) {
   
   Scanner keyboard = new Scanner(System.in);
   
   System.out.println("Moon Hangtime");
   System.out.print("Enter the number of seconds the ball is in the air: " );
   
   //inputs and calculation
   
   double number1 = keyboard.nextDouble();  
   double number2 = 5.32;
   double number3 = 1.622;
   double time1 = number1/2;
   double result1 = (0.5 * number2 * time1 * time1);
   double result2 = (0.5 * number3 * time1 * time1);
   
   System.out.print("\nThe ball's height: " + result1 + " feet or " + result2 + " meters.");
   
    } // end of main method
 }  // end of class HangHeight
   
   
   


