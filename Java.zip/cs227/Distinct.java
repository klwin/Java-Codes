public class Distinct {

   public static void main(String [] args) {
 
      int N = args.length;    
         
              // convert each arg and store them in an array of integers

      int[] values = new int [N];

      for (int i = 0; i < N ; i++)

              values[i] = Integer.parseInt(args[i]);   
      
      
        
              // are all of the pairs examined so far distinct?

      boolean result = true;

              // we'll compare each element (values[i]) in the array ...

      for (int i = 0; i < N; i++) {

                 // ... against the remaining elements (values[j]) ...

        for (int j = i+1;  j < N;  j++) {

                    // ... and change 'result' if they are different

            if (values[i] == values[j]) {
                result = false;
            }

         }  // end j loop

      }  // end i loop
         
      System.out.println(result);
   }
}