/*
   Assignment: #2 Hitting
   Author: Kaung Lwin (klwin@email.arizona.edu)
   Grader: Mervyn Abraham   
   
   Course: CSC 127A
   Instructor: I. Kishi
   Due Date: Feb, 5 9:00pm
   
   Description: The program will compute some baseball hitting statistics for a player.
   
   Deficiencies: 
   */
   public class Hitting // start of main method
   {
      public static void main ( String args [] )
      {
  int bats = 8903; //datas
  int doubles = 547;
  int triples = 38;
  int homeRuns = 467;
  int walks = 1494;
  int sacrificeBunts = 150;
  float battingAverage = 0.3041672F; 
  
         System.out.println ("Larry Wayne \"Chipper\" Jones's career hitting:"); // \" puts quote in the line
         System.out.println ("Provided statistics:");
         System.out.println ("   at Bats:\t\t"    + bats);
         System.out.println ("   doubles:\t\t"   + doubles);
         System.out.println ("   triples:\t\t"   + triples);
         System.out.println ("   home runs:\t\t"  + homeRuns);
         System.out.println ("   walks:\t\t" + walks);
         System.out.println ("   sacrifice bunts:\t"   + sacrificeBunts);
         System.out.println ("   batting average:\t"   + battingAverage);
         System.out.println ("Computed statistics:");
         
 float singles = battingAverage * bats - doubles - triples - homeRuns; // calculation
         System.out.println ("   Singles:\t\t"   + singles);
         
 float totalBases = singles + 2 * doubles + 3 * triples + 4 * homeRuns; //calculation
         System.out.println ("   Total Bases:\t\t"  + totalBases);
         
 float hits = singles + doubles + triples + homeRuns; // calculation
 float on_BasePercentage = (hits + walks ) / (bats + walks); //calculation
      System.out.println ("   On-base Percentage:\t"    + on_BasePercentage);
 
 float sluggingPercentage = totalBases / (bats + sacrificeBunts); //calculation
      System.out.println ("   Slugging Percentage:\t"   + sluggingPercentage);
         
      } // end of main method
   } // end of class