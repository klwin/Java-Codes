/**********************************************************************
 *  N-Body Simulation readme.txt template
 **********************************************************************/


Name:
Login:
Precept:
OS:
Machine (e.g., Dell Latitude, MacBook Pro):
Text editor:
Hours to complete assignment (optional):

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/


/**********************************************************************
 *  StdAudio survey
 **********************************************************************/
Did you try to add the line to play 2001.mid in your program?

If you tried, were you successful?

If unsuccessful, please describe what happened.

If unsuccessful, please run StdAudio (java-introcs StdAudio). 
Did you hear a scale?

/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else?  Please list their names.  ("A Sunday lab TA" or 
 *  "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


