/*Name: Kaung Lwin
  NetID: klwin
  SectionNumber: 1D
  Description: Takes an integer command-line argument N and simulates the 
  motion of a random walker for N steps. After each step, print the location of
  the random walker, treating the lamp post as the origin (0, 0). 
*/

import java.util.Random; //import utility
public class RandomWalker { //start of class
    public static void main(String [] args) { //start of main method
        
        Random randomNumber = new Random(); //generate random number
        int nSteps = Integer.parseInt(args [0]); //take first arg
        //initialize variables
        int directions;
        int x = 0;
        int y = 0;
        double distance;
        
        //loop for nSteps
        for (int i=0; i < nSteps; i++) {
             directions = randomNumber.nextInt(4); // random number from 0-3
             
             if(directions == 0) { //North
                 y++;
             }
        
             if(directions == 1) { //East
                 x++;
             }
        
             if(directions == 2) { //South
                 y--;
             }
             
             if(directions == 3) { //West
                 x--;
             }
             
        System.out.println("(" + x + ", " + y + ")");
        }
        distance = (x * x) + (y * y); //compute the distance
        System.out.println("squared distance = " + (int) distance); 
    } //end of main method
} //end of class
        
        