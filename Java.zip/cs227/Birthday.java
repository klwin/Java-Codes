public class Birthday { 

    public static void main(String[] args) {

        int DAY_QTY = Integer.parseInt(args[0]) ;  // number of days 
        int people = 0;      // number of people who have entered the room 
       
                // days[d] = true if a person has birthday d; false otherwise
                // auto-initialized to false

        boolean [] days  =   new  boolean [DAY_QTY] ;

                // repeat until two people have the same birthday

        while (true) {

                    // increment number of people

            people++ ;

                    // random day between 0 and DAY_QTY-1

            int d = (int) (Math.random()*365);

                    // if another person shares birthday d, break out of loop

            if (days [d])   break;
           
                    // update days[] to indicate person has birthday d

            days[d] = true ;

        }

                // print result - How many people entered the room?

        System.out.println(people);
    }
}