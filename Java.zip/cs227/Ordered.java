/*
 Name: Kaung Lwin
 NetID: klwin
 SectionNumber: 1D
 Description: Return true if the argument numbers are ascending or descending and
              false otherwise.
*/

public class Ordered { //start of class
    public static void main(String [] args) { //start of main method
        
        int x = Integer.parseInt(args[0]); // first arg
        int y = Integer.parseInt(args[1]); // second arg
        int z = Integer.parseInt(args[2]); //third arg
        boolean isOrdered; //initialize boolean
        
        //if for increase and decrease statement
        if ( (x > y && y > z) || (x <y && y < z) ) { 
            isOrdered = true;
        }
        
        else { //else statement
            isOrdered = false;
        }
        
        System.out.println(isOrdered); //prints out true of false
    } //end of main method
} //end of class

             