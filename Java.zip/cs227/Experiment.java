public class Experiment {
    public static void main (String [] args){
        StdDraw.setXscale(-1.0, 1.0);
        StdDraw.setYscale(-1.0, 1.0);
        StdDraw.picture(0, 0, "starfield.jpg", 2.0, 2.0);
    }
}
    