public class BouncingBall{
    public static void main(String [] args){
        //Simulate the movement of a bouncing ball
        //create a 2 by 2 box
        StdDraw.setXscale(-1.0, 1.0);
        StdDraw.setYscale(-1.0, 1.0);
        
        double rx = .480, ry = .860; //position
        double vx = .015, vy = .023; //velocity
        double radius = .05; //ball radius
        while(true){
            if(Math.abs(rx + vx) + radius > 1.0){ //bounce off for x
                vx = -vx;
            }
            if(Math.abs(ry + vy) + radius > 1.0){ //bounece off for y
                vy = -vy;
            }
            rx = rx + vx; //keeps moving in x
            ry = ry + vy; //keeps moving in y
            StdDraw.clear(); //erase the line drawn by dot
            StdDraw.filledCircle(rx, ry, radius); //draw filled dot
            StdDraw.show(20); //speed of the ball
        }
    }
}
            