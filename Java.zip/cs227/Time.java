/*Name: Kaung Lwin
  NetID: klwin
  SectionNumber: 1D
  Description: Takes in numbers in minutes and add it to 12:00pm.
*/

import java.text.DecimalFormat; //import utility

public class Time { //start of class
    public static void main(String [] args) { //start of main method
        int addMinutes = Integer.parseInt(args [0]); //takes first arg
        //equations
        int hours = addMinutes / 60; //determine hours
        int minutes = addMinutes % 60; //determine minutes
        int n = (hours / 12) % 2; //determine am or pm
        DecimalFormat time = new DecimalFormat ("00"); //format for minutes
        String day; //initialize am or pm
        
        if(hours % 12 == 0){ //reset the time to 12 after adding 12 hours
            hours = 12;
        }
        if(hours % 12 >= 1) { //determine hour after adding 12 hours
            hours = hours % 12;
        }
        if (n == 0 ){ //determine pm
            day = "pm";
        }
        else { //determine am
            day = "am";
        }
        System.out.println("Start Time: 12:00pm");
        System.out.println("Finish Time: " + hours + ":" 
                               + time.format(minutes) + day);
        System.out.println();
    } //end of main method
} //end of class
        